import Head from 'next/head'
import {useRouter} from 'next/router'
import Link from 'next/link'

import styles from '../styles/Index.module.css'
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {faBars, faUser, faPen} from '@fortawesome/free-solid-svg-icons'
import { Children } from 'react'

type Navbarprops={
    styles: React.CSSProperties
}


const Navbar=(props: Navbarprops)=> {

  const router= useRouter();
  


  
  
  return (
    <div className={styles.Navbar}>
 
    <Head>
      <title>
        Home
      </title>
    </Head>

      <div className={styles.homeNavbar}>
      <div className={styles.NavbarLeft}>
      <FontAwesomeIcon icon={faBars} style={{'height':'30','color':'white', 'paddingRight':'5px'}} />
      <a href="/dashboard" className={styles.navLinks} onClick={()=>router.push('/dashboard')}><h2>DASHBOARD</h2></a>
      <a href="/Contact" className={styles.navLinks} onClick={()=>router.push('/Contact')}><h2>CONTACT</h2></a>
      </div>
     
     <div className={styles.NavbarCenter}>
       <img className={styles.homeLogo} src='../static/logo2.svg' alt='logo' height={50} style={props.styles} onClick={()=>router.push("/")} />
     </div>
      
      <div className={styles.NavbarRight}>
        <div className={styles.NavbarRightleft}>
          <FontAwesomeIcon icon={faUser} style={{'height':'16','paddingRight':'5px'}}/><h2>LOGIN</h2>
        </div>

        <div className={styles.NavbarRightright}>
         <FontAwesomeIcon icon={faPen} style={{'height':'16','paddingRight':'5px'}}/><h2>REGISTER</h2>
        </div>

      </div>
      </div>
    </div>
  

  )
}

export default Navbar;