import styles from '../styles/footer.module.css'
import logo from '../static/logo.svg'
import { useRouter } from 'next/router'

const Footer=()=> {

   const router=useRouter(); 
  return (
    <div className={styles.footer}>
        <div className={styles.footerElements}>
          <img src={logo} alt="logo" height={70} />
          <div className={styles.footerLinks}>
            <a className={styles.Links} href='/Contact' onClick={()=>router.push('/Contact')}><h2>CONTACTS</h2></a>
            <a className={styles.Links} href='/phones'><h2>PHONES</h2></a>
            <a className={styles.Links} href='/topSearch'><h2>TOP SEARCH</h2></a>


          </div>
        </div>
    </div>
  )
}

export default Footer