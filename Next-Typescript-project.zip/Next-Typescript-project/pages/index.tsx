import styles from '../styles/Home.module.css'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

const  Home=()=> {
  return (
    <>
    <Navbar styles={{'visibility':'hidden'}} />
    <div className={styles.home}>
        <div className={styles.homelogo}>
           <img src="../static/logo.svg" alt="logo" height={70} />
        </div>
        <div className={styles.homeElements}>
          <div className={styles.nav}>
            <a href='/all' className={styles.navLinksactive}>All</a>
            <a href='/companies' className={styles.navLinks}>Companies</a>
            <a href='/all' className={styles.navLinks}>Phones</a>


          </div>
        </div>
    </div>
    <Footer />
    </>
  )
}

export default Home