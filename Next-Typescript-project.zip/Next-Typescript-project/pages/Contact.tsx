import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {faEnvelope, faLocationDot} from '@fortawesome/free-solid-svg-icons'
import { useRouter } from 'next/router'


import Head from 'next/head'

import styles from '../styles/contact.module.css'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'



const Contact=()=>{


    const router=useRouter();
    return(
        <>
        <Navbar styles={{'visibility':'visible'}} />
        <div className={styles.contact}>
            <Head>
                <title>
                    Contact
                </title>
            </Head>
            <h2>Contact</h2>
            <div className={styles.contactElements}>
            

            <div className={styles.contactDetails}>
                <div className={styles.contactDetailsLeft}>
                    <p className={styles.heading}>
                        <FontAwesomeIcon icon={faLocationDot} style={{'color':'green','paddingRight':'10','height':'20'}}/>
                        Headquarters
                    </p>
                    <p className={styles.details}>
                        DHO s.r.o. <br />
                        Borivojova 878/35 <br />
                        130 00 praha 3 <br />
                    </p>

                </div>

                <div className={styles.contactDetailsRight}>
                    <p className={styles.heading}>
                    <FontAwesomeIcon icon={faEnvelope} style={{'color':'green','paddingRight':'10','height':'20'}}/>
                        Email
                    </p>
                    <p className={styles.details}>
                        info@expanzo.com 
                    </p>

                    
                </div>
            </div>
            </div>
        </div>
        <Footer />
        </>
    )
}

export default Contact